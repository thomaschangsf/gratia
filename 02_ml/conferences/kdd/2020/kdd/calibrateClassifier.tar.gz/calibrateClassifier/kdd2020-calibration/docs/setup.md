<h2> Setup </h2>

0. Ensure you have an up to date browser installed (ideally Chrome, Firefox or Safari)

1. Click this link to take you to [the notebook template](https://colab.research.google.com/github/nplan-io/kdd2020-calibration/blob/master/tutorial/KDD%202020%20-%20nPlan%20calibration%20session.ipynb)

2. At the end of the tutorial, follow this link to take you to some [model answers](https://colab.research.google.com/github/nplan-io/kdd2020-calibration/blob/master/tutorial/KDD%202020%20-%20nPlan%20calibration%20session%20(completed).ipynb)

