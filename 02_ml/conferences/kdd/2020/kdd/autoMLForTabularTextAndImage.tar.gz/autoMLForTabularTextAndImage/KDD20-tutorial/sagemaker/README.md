# Configure the SageMaker Instance

Launch a SageMaker instance with p3.2x and run 

```
bash student.sh
```
