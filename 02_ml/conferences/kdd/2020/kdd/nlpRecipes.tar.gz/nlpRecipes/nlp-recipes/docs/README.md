# Documentation

To setup the documentation, first you need to install the dependencies of the cpu environment. For it please follow the [SETUP.md](../SETUP.md). Then type:

    conda activate nlp_cpu
    pip install sphinx_rtd_theme


To build the documentation as HTML:

    cd docs
    make html

