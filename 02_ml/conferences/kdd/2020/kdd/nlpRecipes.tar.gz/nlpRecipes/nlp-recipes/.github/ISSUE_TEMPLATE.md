### Description
<!--- Describe your issue/bug/request in detail -->


### In which platform does it happen?
<!--- Describe the platform where the issue is happening (use a list if needed) -->
<!--- For example: -->
<!--- * Azure Ubuntu Data Science Virtual Machine. -->
<!--- * Other platforms.  -->


### How do we replicate the issue?
<!--- Please be specific as possible (use a list if needed). -->
<!--- For example: -->
<!--- * Create a conda environment for gpu -->
<!--- * Run unit test `test_timer.py` -->
<!--- * ... -->


### Expected behavior (i.e. solution)
<!--- For example:  -->
<!--- * The tests for the timer should pass successfully. -->


### Other Comments
