.. _azureml:

AzureML module
**************************

AzureML module from NLP utilities.

AzureML utils
===============================

.. automodule:: utils_nlp.azureml.azureml_utils
    :members:
    

AzureML utils for BERT
===============================

.. automodule:: utils_nlp.azureml.azureml_bert_util
    :members:


