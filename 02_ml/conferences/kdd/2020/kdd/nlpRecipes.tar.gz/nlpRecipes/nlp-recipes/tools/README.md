# Tools

This submodule includes:
1.  A [script](generate_conda_file.py) to generate the Conda environment file for running Python scripts and notebooks in this Git repo 
2.  Python [script](remove_pixelserver.py) to remove pixelserver tracking from all example notebooks.

